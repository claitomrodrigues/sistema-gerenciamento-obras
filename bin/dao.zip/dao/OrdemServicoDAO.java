package dao;

import connection.ConnectionFactory;
import model.OrdemServico;
import java.sql.*;
import java.util.*;

public class OrdemServicoDAO extends DAOBase {
    public void salvar(OrdemServico o) { executarAtualizacao("INSERT INTO ordem_servico(numero,descricao,local_servico,responsavel,prioridade,status,data_abertura,data_conclusao,observacoes) VALUES(?,?,?,?,?,?,?,?,?)", o, false); }
    public void atualizar(OrdemServico o) { executarAtualizacao("UPDATE ordem_servico SET numero=?,descricao=?,local_servico=?,responsavel=?,prioridade=?,status=?,data_abertura=?,data_conclusao=?,observacoes=? WHERE id=?", o, true); }
    public void deletar(int id) { try(Connection c=ConnectionFactory.getConnection(); PreparedStatement p=c.prepareStatement("DELETE FROM ordem_servico WHERE id=?")){p.setInt(1,id);p.executeUpdate();}catch(Exception e){throw erro("Erro ao excluir ordem de serviço.",e);} }
    public List<OrdemServico> listar(){return consultar("SELECT * FROM ordem_servico ORDER BY data_abertura DESC,id DESC");}
    public List<OrdemServico> listarAbertas(){return consultar("SELECT * FROM ordem_servico WHERE status <> 'CONCLUIDA' AND status <> 'CANCELADA' ORDER BY CASE prioridade WHEN 'URGENTE' THEN 1 WHEN 'ALTA' THEN 2 ELSE 3 END,data_abertura");}
    public OrdemServico buscarPorId(int id){List<OrdemServico> l=consultar("SELECT * FROM ordem_servico WHERE id=?",id);return l.isEmpty()?null:l.get(0);}
    private void executarAtualizacao(String sql,OrdemServico o,boolean id){try(Connection c=ConnectionFactory.getConnection();PreparedStatement p=c.prepareStatement(sql)){int i=1;p.setString(i++,o.getNumero());p.setString(i++,o.getDescricao());p.setString(i++,o.getLocalServico());p.setString(i++,o.getResponsavel());p.setString(i++,o.getPrioridade());p.setString(i++,o.getStatus());setLocalDate(p,i++,o.getDataAbertura());setLocalDate(p,i++,o.getDataConclusao());p.setString(i++,o.getObservacoes());if(id)p.setInt(i,o.getId());p.executeUpdate();}catch(Exception e){throw erro("Erro ao salvar ordem de serviço.",e);}}
    private List<OrdemServico> consultar(String sql,Object... ps){List<OrdemServico> l=new ArrayList<>();try(Connection c=ConnectionFactory.getConnection();PreparedStatement p=c.prepareStatement(sql)){preencherParametros(p,ps);try(ResultSet r=p.executeQuery()){while(r.next()){OrdemServico o=new OrdemServico();o.setId(r.getInt("id"));o.setNumero(r.getString("numero"));o.setDescricao(r.getString("descricao"));o.setLocalServico(r.getString("local_servico"));o.setResponsavel(r.getString("responsavel"));o.setPrioridade(r.getString("prioridade"));o.setStatus(r.getString("status"));o.setDataAbertura(getLocalDate(r,"data_abertura"));o.setDataConclusao(getLocalDate(r,"data_conclusao"));o.setObservacoes(r.getString("observacoes"));l.add(o);}}}catch(Exception e){throw erro("Erro ao consultar ordens de serviço.",e);}return l;}
}
