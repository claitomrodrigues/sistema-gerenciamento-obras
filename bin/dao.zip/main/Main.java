package main;

import javax.swing.SwingUtilities;

import connection.DatabaseInitializer;
import view.MainFrame;
import view.StyleUtils;
import view.usuario.LoginDialog;

public class Main {

    public static void main(String[] args) {
        DatabaseInitializer.inicializar();
        try { StyleUtils.aplicarTema(); } catch (Exception e) { e.printStackTrace(); }

        SwingUtilities.invokeLater(() -> {
            LoginDialog login = new LoginDialog();
            login.setVisible(true);
            if (!login.isAutenticado()) System.exit(0);
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
